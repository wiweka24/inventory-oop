﻿CREATE TABLE [dbo].[CategoryTbl] (
    [CatId]   INT          NOT NULL,
    [CatName] VARCHAR (50) NOT NULL,
    [CatDesc] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([CatId] ASC)
);

