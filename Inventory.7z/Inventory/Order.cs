﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory
{
    public partial class Order : Form
    {
        int num = 0, flag = 0, qty;
        string product;

        public Order()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Coding\Inventory\database\inventorydb.mdf;Integrated Security=True;Connect Timeout=30");

        private void populate()
        {
            Con.Open();
            string query = "select * from ProductTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            prodDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void fillcombo()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("select CatName from CategoryTbl", Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CatName", typeof(string));
            dt.Load(rdr);
            catCb.ValueMember = "CatName";
            catCb.DataSource = dt;
            Con.Close();
        }

        private void Order_Load(object sender, EventArgs e)
        {
            populate();
            fillcombo();
        }

        private void prodDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            product = prodDGV.SelectedRows[0].Cells[1].Value.ToString();
            flag = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (qtyBx.Text == "")
                MessageBox.Show("Enter The Quantity of Products");
            else if (flag == 0)
                MessageBox.Show("Select The Product");
            else
            {
                num = num + 1;
                qty = Convert.ToInt32(qtyBx.Text);
                //newRow.CreateCells(orderDGV);
                //newRow.Cells[0].Value = num + 1;
                //newRow.Cells[1].Value = ProdName.Text;
                //newRow.Cells[2].Value = ProdPrice.Text;
                //newRow.Cells[3].Value = ProdQty.Text;
                prodDGV.DataSource = orderDGV;
                flag = 0;
            }
        }

        private void catCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Con.Open();
            string query = "select * from ProductTbl where ProdCat='" + catCb.SelectedIndex.ToString() + "' ";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            prodDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
